package in.credable.automation.commons.exception;

public class ExcelInitializationException extends RuntimeException {

    public ExcelInitializationException(String message, Throwable cause) {
        super(message, cause);
    }
}
