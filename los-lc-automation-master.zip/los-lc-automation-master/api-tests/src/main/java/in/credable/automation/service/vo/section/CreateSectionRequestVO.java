package in.credable.automation.service.vo.section;

import lombok.Data;

@Data
public class CreateSectionRequestVO {
    private Long programId;
    private String sectionName;
}
