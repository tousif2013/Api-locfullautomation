package in.credable.automation.service.vo.program;

import lombok.Data;

@Data
public class ProgramFieldMappingVO {
    private Long clientFieldMappingId;
    private boolean isMandatory;
}
