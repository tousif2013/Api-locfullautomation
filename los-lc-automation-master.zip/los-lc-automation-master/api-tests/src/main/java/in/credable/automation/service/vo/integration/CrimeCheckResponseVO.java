package in.credable.automation.service.vo.integration;

import lombok.Data;

@Data
public class CrimeCheckResponseVO {
    private String status;
    private String requestTime;
    private String requestId;
}
