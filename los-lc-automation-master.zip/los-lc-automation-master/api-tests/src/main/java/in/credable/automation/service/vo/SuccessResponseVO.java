package in.credable.automation.service.vo;

import lombok.Data;

@Data
public class SuccessResponseVO {
    private String responseCode;
    private String responseMessage;
}
