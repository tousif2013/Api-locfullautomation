package in.credable.automation.service.vo.dataingestion;

public enum CustomPropertyFieldValueType {
    STRING,
    INTEGER,
    FLOAT,
    DATE,
    BOOLEAN
}
