package in.credable.automation.service.vo.core;

import lombok.Data;

@Data
public class FetchBorrowerRequestVO {
    private Long programId;
}
