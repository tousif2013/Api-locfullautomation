package in.credable.automation.service.vo.section;

import lombok.Data;

@Data
public class SectionOrderUpdateRequestVO {
    private Long sectionInstanceId;
    private Integer sequenceNo;
}
