package in.credable.automation.service.vo.dataingestion;

public enum FormatType {
    AMOUNT
}
