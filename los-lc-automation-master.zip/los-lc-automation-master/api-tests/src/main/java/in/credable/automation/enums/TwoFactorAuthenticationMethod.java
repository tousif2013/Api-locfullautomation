package in.credable.automation.enums;

public enum TwoFactorAuthenticationMethod {
    SMS_OTP,
    EMAIL_OTP,
    NONE
}
