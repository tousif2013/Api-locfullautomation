package in.credable.automation.service.vo.section;

import lombok.Data;

@Data
public class SectionProgramMappingRequestVO {
    private Long sectionId;
    private Long programId;
}
