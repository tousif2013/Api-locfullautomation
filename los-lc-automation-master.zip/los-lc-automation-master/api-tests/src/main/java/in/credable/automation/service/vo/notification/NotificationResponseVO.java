package in.credable.automation.service.vo.notification;

import lombok.Data;

@Data
public class NotificationResponseVO {
    private Integer statusCode;
    private String body;
}
