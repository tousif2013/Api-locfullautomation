package in.credable.automation.service.vo.section;

import lombok.Data;

@Data
public class SectionTabVO {
    private Long tabId;
    private String tabName;
    private String tabCode;
}
