package in.credable.automation.service.vo.integration;

import lombok.Data;

@Data
public class CrimeCheckReportVO {
    private String docVaultUrl;
}
