package in.credable.automation.service.vo.integration;

public enum VendorStatusEnum {
    ACTIVE,
    INACTIVE
}
