package in.credable.automation.service.vo.core;

import lombok.Data;

@Data
public class BorrowerFieldMappingVO {

    private String fieldName;
    private String customName;
    private String formatType;

}
