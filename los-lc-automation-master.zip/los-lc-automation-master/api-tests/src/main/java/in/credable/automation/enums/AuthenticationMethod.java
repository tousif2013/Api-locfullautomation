package in.credable.automation.enums;

public enum AuthenticationMethod {
    MOBILE_AND_OTP,
    EMAIL_AND_PASSWORD,
    NONE
}
