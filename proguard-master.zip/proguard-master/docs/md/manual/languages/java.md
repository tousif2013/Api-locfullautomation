## Java language support

!!! Warning
    ProGuard no longer supports backporting, and cannot backport class files compiled with Java >11.

Provide supports Java versions up to and including 19.
